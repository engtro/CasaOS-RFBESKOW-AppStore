
# Nextcloud Custom

Nextcloud Customized image for support inotify, zipper, extract apps.

---

**Homepage:** https://hub.docker.com/r/rfbeskow/nextcloud-custom

**WebUI Port:** `8089`